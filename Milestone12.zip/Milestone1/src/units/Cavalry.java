package units;

public class Cavalry extends Unit{

	public Cavalry(int level, int maxSoldierCount, int currentSoldierCount,
			double idleUpkeep, double marchingUpkeep, double siegeUpkeep) {
		super(level, maxSoldierCount, currentSoldierCount, idleUpkeep, marchingUpkeep,
				siegeUpkeep);
	}

}
