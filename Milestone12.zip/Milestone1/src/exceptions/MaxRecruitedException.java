package exceptions;

public class MaxRecruitedException extends BuildingException{
	public MaxRecruitedException() 
	{
		super();
	}
	public MaxRecruitedException(String s) 
	{
		super(s);
	}

}
