package exceptions;

public abstract class ArmyException extends EmpireException{
	public ArmyException() 
	{
		super();
	}
	public ArmyException(String s) 
	{
		super(s);
	}
}
