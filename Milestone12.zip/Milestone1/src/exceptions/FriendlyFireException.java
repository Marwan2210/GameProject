package exceptions;

public class FriendlyFireException extends ArmyException {
	public FriendlyFireException() 
	{
		super();
	}
	public FriendlyFireException(String s) 
	{
		super(s);
	}
}
