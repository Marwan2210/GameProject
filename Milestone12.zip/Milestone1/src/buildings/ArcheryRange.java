package buildings;

public class ArcheryRange extends MilitaryBuilding {
	public ArcheryRange()
	{
		super(1500,800,400);
	}
}
