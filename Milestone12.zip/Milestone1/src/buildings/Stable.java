package buildings;

public class Stable extends MilitaryBuilding {
	public Stable() 
	{
		super(2500,1500,600);
	}
}
