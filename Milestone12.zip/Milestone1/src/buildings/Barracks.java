package buildings;

public class Barracks extends MilitaryBuilding {
	public Barracks() 
	{
		super(2000,1000,500);
	}
}
