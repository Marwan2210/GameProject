package buildings;

public class Farm extends EconomicBuilding {
	public Farm() {
	super(1000,500);
	}
}
