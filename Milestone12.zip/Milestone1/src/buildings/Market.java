package buildings;

public class Market extends EconomicBuilding{
	public Market() 
	{
		super(1500,700);
	}

}
