package units;

public class Archer extends Unit{

	public Archer(int level, int maxSoldierCount, int currentSoldierCount,
			double idleUpkeep, double marchingUpkeep, double siegeUpkeep) {
		super(level, maxSoldierCount, currentSoldierCount, idleUpkeep, marchingUpkeep,
				siegeUpkeep);
	}
	
}
